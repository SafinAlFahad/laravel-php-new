<?php

include_once 'baseController.php';


function store()
{
    $id = $_SESSION["user"]->id;
    $s = "select sum(selling_price * quantity) total from cart_book where empid = " . $id;
    $jsonData = readQuery($s);
    $data = json_decode($jsonData);
    $total = $data[0]->total;
    if ($data == 0) {
        return;
    }
    $s = "INSERT INTO `transections`(`id`, `empid`, `total`) VALUES(null," . $id . "," . $total . ")";
    $id = executeQuery($s);

    return $id;
}
