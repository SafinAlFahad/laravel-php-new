<?php

include_once 'baseController.php';
if (isset($_REQUEST['submit'])) {
    store();
}

function employeeReport()
{
    $s = "select t.*,e.name from transactions t, employee e where e.id = t.empid and (datetime BETWEEN CONCAT(CURDATE(), ' 00:00:00') AND CONCAT(CURDATE(), ' 23:59:00')) and t.empid = " . $_SESSION["user"]->id;
    $jsonData = readQuery($s);
    $data = json_decode($jsonData);

    return $data;
}
function adminReport()
{
    $s = "select t.*,e.name from transactions t, employee e where e.id = t.empid and (datetime BETWEEN CONCAT(CURDATE(), ' 00:00:00') AND CONCAT(CURDATE(), ' 23:59:00'))";
    $jsonData = readQuery($s);
    $data = json_decode($jsonData);

    return $data;
}
function store()
{
    $datefrom = $_REQUEST["datefrom"];
    $dateto = $_REQUEST["dateto"];
    $s = "select t.*,e.name from transactions t, employee e where e.id = t.empid and t.empid = " . $_SESSION["user"]->id . " and date between('" . $datefrom . ",'" . $dateto . "'') ";
    $jsonData = readQuery($s);
    $data = json_decode($jsonData);

    return $data;
}
function invoiceBook()
{
    $s = "select i.*, b.name name ,b.code code from invoice i, book b where i.bid = b.id and i.transection_id = " . $_REQUEST["id"];
    $jsonData = readQuery($s);
    $data = json_decode($jsonData);

    return $data;
}
function invoiceTransection()
{
    $s = "select i.*, sum(quantity) total_quantity, t.total total_price,t.datetime ,e.name from invoice i, transections t , employee e where i.transection_id = t.id and e.id = t.empid and t.id = " . $_REQUEST["id"] . " group by transection_id";
    $jsonData = readQuery($s);
    $data = json_decode($jsonData);

    return $data;
}
function invoiceTotal()
{
    $s = "select sum(total)  total from transactions where (datetime BETWEEN CONCAT(CURDATE(), ' 00:00:00') AND CONCAT(CURDATE(), ' 23:59:00')) and empid = " . $_SESSION["user"]->id;
    $jsonData = readQuery($s);
    $data = json_decode($jsonData);

    return $data;
}
function adminInvoiceTotal()
{
    $s = "select sum(total) total from transactions where (datetime BETWEEN CONCAT(CURDATE(), ' 00:00:00') AND CONCAT(CURDATE(), ' 23:59:00'))";
    $jsonData = readQuery($s);
    $data = json_decode($jsonData);

    return $data;
}
