<?php
define('CON_ROOT', "$_SERVER[DOCUMENT_ROOT]/LMS/");
define('VIEW_ROOT', "/LMS/views/");
include_once(CON_ROOT . 'app/model/model.php');
include_once(CON_ROOT . 'app/session.php');
    //echo(CON_ROOT);
