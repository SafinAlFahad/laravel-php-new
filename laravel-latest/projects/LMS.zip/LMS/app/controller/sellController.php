<?php

include_once 'baseController.php';

if (isset($_REQUEST['add'])) {
    cart();
}
if (isset($_REQUEST['clear'])) {
    clear();
}
function index()
{
    $s = "select * from book";
    $jsonData = readQuery($s);
    $data = json_decode($jsonData);

    return $data;
}
function cartBook()
{
    $s = "select * from cart_book where empid = " . $_SESSION["user"]->id;
    $jsonData = readQuery($s);
    $data = json_decode($jsonData);

    return $data;
}

function category()
{
    $s = "select * from category";
    $jsonData = readQuery($s);
    $data = json_decode($jsonData);

    return $data;
}



function cart()
{
    if (!isset($_REQUEST['book'])) {
        header('Location: sell.php');
        return;
    }
    $book = $_REQUEST['book'];
    $quantity = $_REQUEST['quantity'];
    $empid = $_SESSION["user"]->id;

    $s = "select * from cart where empid = " . $empid . " and bid = " . $book;
    $jsonData = readQuery($s);
    $data = json_decode($jsonData);
    if (count($data) > 0) {
        $s = "update cart set quantity = quantity + " . $quantity . " where  empid = " . $empid . " and bid = " . $book;
        $data = deleteAndUpdateQuery($s);
        header('Location: sell.php');
        return;
    }

    $s = "INSERT INTO `cart`(`id`, `bid`, `quantity`, `empid`) VALUES (null," . $book . "," . $quantity . "," . $empid . ")";
    $id = executeQuery($s);

    // print_r($id);
    if ($id > 0) {
        header('Location: sell.php');
        return;
    }
    return $id;
}
function delete($id = 0)
{
    $id = $_REQUEST["id"];
    // var_dump($id);
    $s = "delete from cart where id = " . $id;
    deleteAndUpdateQuery($s);

    header('Location: sell.php');
    return;
}
function clear()
{
    $s = "delete from cart where empid = " . $_SESSION["user"]->id;
    deleteAndUpdateQuery($s);

    header('Location: sell.php');
    return;
}
