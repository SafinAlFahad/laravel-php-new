<?php

include_once 'baseController.php';


function invoice($trId)
{
    $id = $_SESSION["user"]->id;

    $s = "select * from cart_book where empid = " . $id;
    $jsonData = readQuery($s);
    $data = json_decode($jsonData);
    // print_r($data);
    foreach ($data as $b) {
        $s = "INSERT INTO `invoice`(`id`, `bid`, `buying_price`, `selling_price`, `quantity`, `total`, `transection_id`) VALUES (null," . $b->book_id . "," . $b->buying_price . "," . $b->selling_price . "," . $b->quantity . "," . $b->selling_price * $b->quantity . "," . $trId . ")";
        $id = executeQuery($s);
        $s = "update book set quantity = quantity-$b->quantity where id = " . $b->book_id;
        deleteAndUpdateQuery($s);
    }
    $s = "select i.*, b.name from invoice i, book b where transection_id = " . $trId . " and i.bid    = b.id";
    $jsonData = readQuery($s);
    $data = json_decode($jsonData);
    clear();

    return $data;
}
function clear()
{
    $s = "delete from cart where empid = " . $_SESSION["user"]->id;
    deleteAndUpdateQuery($s);
    return;
}
