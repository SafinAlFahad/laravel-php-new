<?php

include_once 'baseController.php';

if (isset($_REQUEST['submit'])) {
    store();
}
function index()
{
    $s = "select * from employee";
    $jsonData = readQuery($s);
    $data = json_decode($jsonData);

    return $data;
}
function show($id = 0)
{
    $id = $_REQUEST["id"];
    // var_dump($id);
    $s = "select * from employee where id = " . $id;
    $jsonData = readQuery($s);
    $data = json_decode($jsonData);

    return $data;
}
function profile($id = 0)
{
    $id = $_SESSION["user"]->id;
    // var_dump($id);
    $s = "select * from employee where id = " . $id;
    $jsonData = readQuery($s);
    $data = json_decode($jsonData);

    return $data;
}
function create()
{
}



function store()
{
    $name = $_REQUEST['name'];
    $phone = $_REQUEST['phone'];
    $username = $_REQUEST['username'];
    $password = md5($_REQUEST['password']);
    $type = $_REQUEST['type'];
    $s = "INSERT INTO `employee`(`id`, `name`, `phone`, `username`, `password`, `type`) VALUES (null,'" . $name . "','" . $phone . "','" . $username . "','" . $password . "','" . $type . "')";
    $id = executeQuery($s);

    // print_r($id);
    if ($id > 0) {
        header('Location: show.php?id='.$id);
        return;
    }
}
