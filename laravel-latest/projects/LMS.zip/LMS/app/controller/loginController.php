<?php

include_once 'baseController.php';

if (isset($_REQUEST['submit'])) {
    login();
}
function index()
{
    $s = "select * from employee";
    $jsonData = readQuery($s);
    $data = json_decode($jsonData);

    return $data;
}

function create()
{
}



function login()
{
    $username = $_REQUEST['username'];
    $password = md5($_REQUEST['password']);

    $s = "select id,name,username,type from employee where username = '" . $username . "' and password = '" . $password . "' ";
    // var_dump($s);
    $jsonData = readQuery($s);
    $data = json_decode($jsonData);

    // var_dump($data);
    // print_r($id);
    if (count($data) > 0) {
        $_SESSION["user"] = $data[0];
        header('Location: employee/profile.php');
        return;
    }
}
function logout()
{
    session_destroy();
    header('location: login.php');
}
