Admin panel: 
username: a 
password:abc

salesman:
username: s
password: s