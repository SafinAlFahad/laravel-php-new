<?php

include_once 'baseController.php';


function invoice($trId)
{
    $id = $_SESSION["user"]->id;

    $s = "select * from cart_product where empid = " . $id;
    $jsonData = readQuery($s);
    $data = json_decode($jsonData);
    // print_r($data);
    foreach ($data as $p) {
        $s = "INSERT INTO `invoice`(`id`, `pid`, `buying_price`, `selling_price`, `quantity`, `total`, `transection_id`) VALUES (null," . $p->product_id . "," . $p->buying_price . "," . $p->selling_price . "," . $p->quantity . "," . $p->selling_price * $p->quantity . "," . $trId . ")";
        $id = executeQuery($s);
        $s = "update product set quantity = quantity-$p->quantity where id = " . $p->product_id;
        deleteAndUpdateQuery($s);
    }
    $s = "select i.*, p.name from invoice i, product p where transection_id = " . $trId . " and i.pid    = p.id";
    $jsonData = readQuery($s);
    $data = json_decode($jsonData);
    clear();

    return $data;
}
function clear()
{
    $s = "delete from cart where empid = " . $_SESSION["user"]->id;
    deleteAndUpdateQuery($s);
    return;
}
