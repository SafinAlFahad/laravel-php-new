<?php

include_once 'baseController.php';

if (isset($_REQUEST['add'])) {
    cart();
}
if (isset($_REQUEST['clear'])) {
    clear();
}
function index()
{
    $s = "select * from product";
    $jsonData = readQuery($s);
    $data = json_decode($jsonData);

    return $data;
}
function cartProduct()
{
    $s = "select * from cart_product where empid = " . $_SESSION["user"]->id;
    $jsonData = readQuery($s);
    $data = json_decode($jsonData);

    return $data;
}

function category()
{
    $s = "select * from category";
    $jsonData = readQuery($s);
    $data = json_decode($jsonData);

    return $data;
}



function cart()
{
    if (!isset($_REQUEST['product'])) {
        header('Location: sell.php');
        return;
    }
    $product = $_REQUEST['product'];
    $quantity = $_REQUEST['quantity'];
    $empid = $_SESSION["user"]->id;

    $s = "select * from cart where empid = " . $empid . " and pid = " . $product;
    $jsonData = readQuery($s);
    $data = json_decode($jsonData);
    if (count($data) > 0) {
        $s = "update cart set quantity = quantity + " . $quantity . " where  empid = " . $empid . " and pid = " . $product;
        $data = deleteAndUpdateQuery($s);
        header('Location: sell.php');
        return;
    }

    $s = "INSERT INTO `cart`(`id`, `pid`, `quantity`, `empid`) VALUES (null," . $product . "," . $quantity . "," . $empid . ")";
    $id = executeQuery($s);

    // print_r($id);
    if ($id > 0) {
        header('Location: sell.php');
        return;
    }
    return $id;
}
function delete($id = 0)
{
    $id = $_REQUEST["id"];
    // var_dump($id);
    $s = "delete from cart where id = " . $id;
    deleteAndUpdateQuery($s);

    header('Location: sell.php');
    return;
}
function clear()
{
    $s = "delete from cart where empid = " . $_SESSION["user"]->id;
    deleteAndUpdateQuery($s);

    header('Location: sell.php');
    return;
}
