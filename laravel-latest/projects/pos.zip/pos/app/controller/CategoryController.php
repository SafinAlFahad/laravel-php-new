<?php include_once('BaseController.php');

if (isset($_REQUEST['SAVE'])) {
    store();
}

function index() //index for showing list of the entity
{
    $s = "select * from category";
    $jsonData = readQuery($s);

    
    $emp = json_decode($jsonData);
    // print_r($emp);
    return $emp;
}

function create()
{

}

function store()
{
    $name = $_REQUEST['name'];
    
    $s = "INSERT INTO `category`(`id`, `name`) VALUES (NULL,'$name')";
    $r = executeQuery($s);

    // print_r($r);
    if($r == 0)
    {
        echo "error";
    }
    else
    {
        // echo "successfully created";
        header("location: index.php");
    }
}

function show() //show for showing a single a entity
{

}

function delete() //delete for delete a single a entity
{

}