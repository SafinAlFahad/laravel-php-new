<?php

include_once 'baseController.php';

if (isset($_REQUEST['submit'])) {
    store();
}
if (isset($_REQUEST['addQuantity'])) {
    addQuantity();
}
function index()
{
    $s = "select p.*, c.name category_name from product p,category c where p.category_id = c.id";
    $jsonData = readQuery($s);
    $data = json_decode($jsonData);

    return $data;
}

function category()
{
    $s = "select * from category";
    $jsonData = readQuery($s);
    $data = json_decode($jsonData);

    return $data;
}



function store()
{
    $name = $_REQUEST['name'];
    $buyingPrice = $_REQUEST['buyingPrice'];
    $sellingPrice = $_REQUEST['sellingPrice'];
    $productCode = $_REQUEST['productCode'];
    $quantity = $_REQUEST['quantity'];
    $category = $_REQUEST['category'];
    $status = "AVAILABLE";
    $s = "INSERT INTO `product`(`id`, `name`, `quantity`, `buying_price`, `selling_price`, code,`status`,category_id) VALUES (null,'" . $name . "'," . $quantity . ",'" . $buyingPrice . "','" . $sellingPrice . "','" . $productCode . "','" . $status . "'," . $category . ")";
    $id = executeQuery($s);

    // print_r($id);
    if ($id > 0) {
        header('Location: index.php');
        return;
    }
    return $id;
}
function show($id = 0)
{
    $id = $_REQUEST["id"];
    // var_dump($id);
    $s = "select p.*, c.name category_name from product p,category c where p.category_id = c.id and p.id = " . $id;
    $jsonData = readQuery($s);
    $data = json_decode($jsonData);

    return $data;
}
function addQuantity()
{
    $id = $_REQUEST["id"];
    $quantity = $_REQUEST["quantity"];
    // var_dump($id);
    $s = "update product set quantity = quantity + " . $quantity . " where id = " . $id;
    $data = deleteAndUpdateQuery($s);

    return $data;
}
