<?php

include_once 'baseController.php';

if (isset($_REQUEST['submit'])) {
    store();
}
function index()
{
    $s = "select * from department";
    $jsonData = readQuery($s);
    $data = json_decode($jsonData);

    return $data;
}

function create()
{
}



function store()
{
    $name = $_REQUEST['name'];
    $loc = $_REQUEST['loc'];
    $s = "INSERT INTO `department`(`id`, `name`, `loc`) VALUES (null,'" . $name . "','" . $loc . "')";
    $id = executeQuery($s);

    // print_r($id);
    if ($id > 0) {
        header('Location: index.php');
    }
    return $id;
}
