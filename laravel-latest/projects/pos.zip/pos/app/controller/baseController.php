<?php
define('CON_ROOT', "$_SERVER[DOCUMENT_ROOT]/pos/");
define('VIEW_ROOT', "/pos/views/");
include_once(CON_ROOT . 'app/model/model.php');
include_once(CON_ROOT . 'app/session.php');
    //echo(CON_ROOT);
